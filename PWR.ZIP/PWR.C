#include <stdio.h>
#define OFF off()
#define egetc getc
static char cn[]="��ѵ������ս����ɻ��ͺ˹��ΰ����ڿ��ĳ´�������߀������������H����������������������������������p�������������������������������";

extern long (ftell)();

typedef struct fsc048
{
	unsigned int orig_node,dest_node,year,month,day,hour,minute,
        second,rate,ver,orig_net,dest_net;
	char product,rev_lev,password[8];
	unsigned int qm_orig_zone,qm_dest_zone,aux_net;
	unsigned int capword2;
	char product2,rev_lev2;
	unsigned int capword,orig_zone,dest_zone,orig_point,dest_point;
	long pr_data;
} MED2PK;

typedef struct HDR000
{
    unsigned int xonode,xdnode,xonet,xdnet,xattr;
    int          xcost;
} MSGHDR;

MED2PK	pl=
{
	7777,7777,
	0,0,0,0,0,0,0,2,
	7777,7777,'\1','\1',"\0\0\0\0\0\0\0",0,0,7777,256,'\1','\1',
	1,7777,7777,7777,7777,0L
};
MSGHDR	mh;
FILE	*infile,*outfile;

char $$prom[]="\15pwr> \200";
char name[20],jcname[20],jcdev[20],sto[38],sfrom[38];
char subj[74],area[74],reply[74],string[128];
char tear[128],lorigin[128],fromname[128],toname[128];
char defarea[128];
int  d1=0,d2=0,d3=0,d4=0,d5=0,d6=0;
int  i,fmpt,topt,xdate[20],bug=0,msg=0,ins=0,den=0;
long ltim,pden;
int issubj,istear;

main(n,v)
char *v[];
{
	if(n!=2) about();
	if(*v[1]=='&'){	bug++;	v[1]++;	}
	if(*v[1]=='^'){	ins++;	v[1]++; }
	if(*v[1]=='#'){	den++;	v[1]++;	}
	if(frp1(name,v[1],"dk:",".lst","\0","dk:noname.lst"))
	{
		printf("????? bad file name '%s'\n",v[1]);
		exit(1);
	}
	infile=fopen(name,"r");
	if(infile==0)
	{
		printf("????? can't open file '%s' for read\n",name);
		exit(1);
	}
	if(frp2(jcdev,jcname,0,0,v[1]))
	{
		printf("????? sudden can't parse '%s'\n",v[1]);
		exit(1);
	}
	if(frp1(name,jcname,jcdev,".pkt","\0","dk:noname.pkt"))
	{
		printf("????? bad creation of file name '%s'\n",name);
		exit(1);
	}
	outfile=fopen(name,"wn");
	if(outfile==0)
	{
		printf("????? can't open file '%s' for writing\n",name);
		exit(1);
	}
	printf("Taking header for packet...\n");
	fscanf(infile,"%s",string);
	pl.orig_point=0;
	if(fscanf(infile,"%d:%d/%d.%d",&pl.orig_zone,&pl.orig_net,&pl.orig_node,&pl.orig_point)<3) printf("Incomplete 'from' address in 'packet:'\n");
	printf("Packet from %d:%d/%d.%d\n",pl.orig_zone,pl.orig_net,pl.orig_node,pl.orig_point);
	pl.aux_net=pl.orig_net;
	if(pl.orig_point) pl.orig_net=(-1);
	pl.dest_point=0;
	if(fscanf(infile,"%d:%d/%d.%d",&pl.dest_zone,&pl.dest_net,&pl.dest_node,&pl.dest_point)<3) printf("Incomplete 'to' address in 'packet:'\n");
	printf("Packet  to  %d:%d/%d.%d\n",pl.dest_zone,pl.dest_net,pl.dest_node,pl.dest_point);
	fscanf(infile,"%8s",&pl.password);
	pl.qm_orig_zone=0;
	if(fwrite(&pl,1,sizeof(MED2PK),outfile)!=sizeof(MED2PK)) OFF;
	printf("Taking messages from packet ...\n");
	$gtim(&ltim);
	ltim|=((long)date())<<16;
	*tear=0;
	*fromname=0;
	*lorigin=0;
	*toname=0;
	*defarea=0;
	for(;;)
	{
		fmpt=0;
		topt=0;
ax000:		if(bug) printf("Control\n");
		i=getc(infile);
		if(i=='\n') goto ax000;
		if(i== -1) break;
		ungetc(i,infile);
		fscanf(infile,"%s",string);dropsp();
		if(bug) printf("Str: '%s'\n",string);
		if(streq(string,"tearline")) {
			fgetss(tear,128,infile);
			cns(tear);
			goto ax000;}
		if(streq(string,"origin")) {
			fgetss(lorigin,128,infile);
			cns(lorigin);
			goto ax000;}
		if(streq(string,"fromname")) {
			fgetss(fromname,36,infile);
			goto ax000;}
		if(streq(string,"toname")) {
			fgetss(toname,36,infile);
			goto ax000;}
		if(streq(string,"defarea")) {
			fgetss(defarea,36,infile);
			goto ax000;}
		if(streq(string,"defmessag")) {
			d1=7777;d2=7777;d3=0;d4=7777;d5=7777;d6=0;
			if(fscanf(infile,"%d/%d.%d",&d1,&d2,&d3)<2) printf("Incomplete 'from' address in 'defmesssag:'\n");
			if(fscanf(infile,"%d/%d.%d",&d4,&d5,&d6)<2) printf("Incomplete 'to' address in 'defmesssag:'\n");
			goto ax000;}
		mh.xonet=d1;mh.xonode=d2;fmpt=d3;
		mh.xdnet=d4;mh.xdnode=d5;topt=d6;
		stos(fromname,sfrom);
		stos(toname,sto);
		issubj=0;
		istear=1;
		stos(defarea,area);
		*reply=0;
		goto ax002;
ax001:		i=getc(infile);
		if(i== -1) {printf("����������� ����� �����.");exit(1);}
		if(i=='\n') goto ax001;
		if(i=='\2') goto axpost;
		ungetc(i,infile);
		fscanf(infile,"%s",string);dropsp();
ax002:		if(bug) printf("ax002\n");
		if(bug) printf("Str: '%s'\n",string);
		if(streq(string,"messag")) {
			fscanf(infile,"%d/%d.%d",&mh.xonet,&mh.xonode,&fmpt);
			fscanf(infile,"%d/%d.%d",&mh.xdnet,&mh.xdnode,&topt);
			if(bug) printf("Message from %d/%d.%d to %d/%d.%d \n",mh.xonet,mh.xonode,fmpt,mh.xdnet,mh.xdnode,topt);
			goto ax001;}
		if(streq(string,"dest")) {
			fscanf(infile,"%d/%d.%d",&mh.xdnet,&mh.xdnode,&topt);
			if(bug) printf("Message from %d/%d.%d to %d/%d.%d \n",mh.xonet,mh.xonode,fmpt,mh.xdnet,mh.xdnode,topt);
			goto ax001;}
		if(streq(string,"from")) {
			fgetss(sfrom,36,infile);
			goto ax001;}
		if(streq(string,"to")) {
			fgetss(sto,36,infile);
			goto ax001;}
		if(streq(string,"subj")) {
			issubj=1;
			fgetss(subj,72,infile);
			goto ax001;}
		if(streq(string,"area")) {
			fgetss(area,72,infile);
			goto ax001;}
		if(streq(string,"reply")) {
			fgetss(reply,72,infile);
			goto ax001;}
		if(streq(string,"noinfo")) {
			istear=0;
			goto ax001;}
		printf("Bad identificator: '%s'\n",string);
		exit(1);
axpost:		if(msg) putc(0,outfile);
		putc(2,outfile);
		putc(0,outfile);
		if(fwrite(&mh,1,sizeof(mh),outfile)!=sizeof(mh)) OFF;
		makdat();
		pustr(xdate+2);
		pustr(sto);
		pustr(sfrom);
		pustr(subj);
		if(area[0]) fprintf(outfile,"AREA:%s\r",area);
		if((!area[0]||ins) && fmpt) fprintf(outfile,"\1FMPT %d\r",fmpt);
		if((!area[0]||ins) && topt) fprintf(outfile,"\1TOPT %d\r",topt);
		sprintf(subj,"\1MSGID: %d:%d/%d.%d %08Lx",pl.orig_zone,mh.xonet,mh.xonode,fmpt,ltim);
		ltim+=1700013L;
		tolower(subj);
		fprintf(outfile,"%s\r",subj);
		if(reply[0]) fprintf(outfile,"\1REPLY: %s\r",reply);
		for(;;)
		{
			i=egetc(infile);
			if(i==-1) break;
			if(i==2) break;
			if(i=='\n') i='\r';
			putc(cnv(i),outfile);
			if(ferror(outfile)) OFF;
			if(ferror(infile))
			{
				printf("Read error\n");
				exit(1);
			}
		}
		if(istear)
		{
			fprintf(outfile,"--- %s\r",tear);
			fprintf(outfile," * Origin: %s\r",lorigin);
		}
		if(area[0])
		{
			fprintf(outfile,"SEEN-BY: %d/%d\r",pl.dest_net,pl.dest_node);
			fprintf(outfile,"\1PATH: %d/%d\r",pl.dest_net,pl.dest_node);
		}
		pden=ftell(outfile);
		msg++;
		goto ax000;
	}
	if(den)
	{
		fseek(outfile,pden,0);
		i=(((int*)(&pden))[1]);
		i=512-i-3;
		printf("%d\n",i);
		if(i<0) i+=512;
		for(;i--;) putc(32,outfile);
	}
	putc(0,outfile);
	putc(0,outfile);
	putc(0,outfile);
	fclose(infile);
	fclose(outfile);
	printf("Messages = %d\n",msg);
	exit(1);
}
dropsp()
{
	int i;
	do
	{
		i=egetc(infile);
		if(i==-1) return;
	} while(i==' ' || i=='\t');
	ungetc(i,infile);
}


cnv(c)
{
	return ((c&0377)>0177)?cn[c&0177]:c;
}


cns(s)
char *s;
{
	for(;*s;*s++=(cnv(*s)));
}

pustr(s)
char *s;
{
	int a;
	do
	{
		a=cnv(*s);
		putc(a,outfile);
	} while(*s++);
}

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   